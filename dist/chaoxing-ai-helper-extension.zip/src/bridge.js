/* 学习通 AI 答题助手 · 桥接（ISOLATED world）
   页面(MAIN world)通过 window.postMessage 发请求，这里转给 background，
   background 拿到结果后再 postMessage 回页面。 */
(function () {
    'use strict';
    var CH = '__xxt_gm_bridge__';

    window.addEventListener('message', function (ev) {
        if (ev.source !== window) return;
        var d = ev.data;
        if (!d || d.__xxt !== CH || d.dir !== 'req') return;

        var send = function (resp) {
            try {
                window.postMessage({ __xxt: CH, dir: 'res', id: d.id, payload: resp || { ok: false, error: 'no response' } }, '*');
            } catch (e) { }
        };

        try {
            chrome.runtime.sendMessage({ __xxt: CH, dir: 'req', id: d.id, payload: d.payload }, function (resp) {
                if (chrome.runtime.lastError) {
                    send({ ok: false, error: String(chrome.runtime.lastError.message || 'runtime error') });
                    return;
                }
                send(resp);
            });
        } catch (e) {
            send({ ok: false, error: String(e && e.message ? e.message : e) });
        }
    });
})();
