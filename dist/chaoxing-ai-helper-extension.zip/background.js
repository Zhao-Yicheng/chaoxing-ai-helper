/* 学习通 AI 答题助手 · 后台（MV3 service worker）
   代替 GM_xmlhttpRequest 做跨域请求，规避页面 CORS 限制。 */
'use strict';

var CH = '__xxt_gm_bridge__';

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.__xxt !== CH || msg.dir !== 'req') return undefined;

    var p = (msg && msg.payload) || {};
    var ctrl = new AbortController();
    var timer = p.timeout ? setTimeout(function () { try { ctrl.abort(); } catch (e) { } }, p.timeout) : null;

    var init = {
        method: p.method || 'GET',
        headers: p.headers || {},
        credentials: 'omit',
        cache: 'no-store',
        signal: ctrl.signal
    };
    if (p.data !== undefined && p.data !== null) init.body = p.data;

    fetch(p.url, init).then(function (resp) {
        return resp.text().then(function (text) {
            if (timer) clearTimeout(timer);
            sendResponse({
                ok: true,
                status: resp.status,
                statusText: resp.statusText || '',
                responseText: text,
                url: resp.url || p.url
            });
        });
    }).catch(function (err) {
        if (timer) clearTimeout(timer);
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
    });

    return true;   // 异步响应
});
